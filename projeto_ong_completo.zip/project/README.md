# Plataforma Web para ONGs

## Tecnologias
- HTML5 semântico
- CSS3 avançado (Grid, Flexbox, responsividade)
- JavaScript dinâmico (menu responsivo, validação, animações)

## Acessibilidade
- WCAG 2.1 AA
- Navegação por teclado
- Contraste adequado

## SEO
- Meta tags otimizadas
- Estrutura semântica

## Como executar
Abra index.html em um navegador.

## Estrutura
- index.html: Página inicial
- projetos.html: Projetos sociais
- cadastro.html: Formulário

## Próximas etapas
- Integração com backend
- Deploy em servidor
